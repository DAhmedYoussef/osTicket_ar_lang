<?php return array (
  'Build-Date' => 'Thu, 07 Sep 23 15:47:07 +0000',
  'Phrases-Version' => '1.18',
  'Build-Version' => 'v1.18',
  'Build-Major-Version' => '1.18',
  'Language' => 'ar_SA',
  'Id' => 'lang:ar',
  'Last-Revision' => '2023-07-11 20:55',
  'Version' => 168910,
);